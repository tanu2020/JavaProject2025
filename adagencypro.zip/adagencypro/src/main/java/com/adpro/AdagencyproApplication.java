package com.adpro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AdagencyproApplication {

	public static void main(String[] args) {
		SpringApplication.run(AdagencyproApplication.class, args);
	}

}
